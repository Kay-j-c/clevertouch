import React, { useState } from "react"
import './Navbar.css'
import { assets } from "../../assets/assets"


const Navbar = ({setShowLogin}) => {
  
    const [menu,setMenu] = useState("menu");

    return (
      <div className='navbar'>
        <img src={assets.logo} alt="" className="logo"/>
        <ul className="navbar-menu">
            <li onClick ={()=>setMenu("home")} className={menu==="home"?"active":""}>Home</li>
            <li onClick ={()=>setMenu("login")} className={menu==="menu"?"active":""}>About</li>
            
        </ul>
        <div className="navbar-right">
          <button onClick={()=>setShowLogin(true)}>Sign In</button>
        </div>
      </div>
    )
  }
  
  export default Navbar
  