import React, { useState } from "react";
import './LoginPopup.css'
import { assets } from "../../assets/assets";

const LoginPopup = ({ setShowLogin }) => {
    const [currState, setCurrState] = useState("Sign Up");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [agreeTerms, setAgreeTerms] = useState(false);
    const [formErrors, setFormErrors] = useState({});

    const handleSignUp = (e) => {
        e.preventDefault();
        // Validate form fields
        const errors = {};
        if (!name.trim()) {
            errors.name = "Name is required";
        }
        if (!email.trim()) {
            errors.email = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(email)) {
            errors.email = "Email is invalid";
        }
        if (!password.trim()) {
            errors.password = "Password is required";
        } else if (password.length < 6) {
            errors.password = "Password must be at least 6 characters";
        }
        if (!agreeTerms) {
            errors.agreeTerms = "Please agree to the terms";
        }
        setFormErrors(errors);
        if (Object.keys(errors).length === 0) {
            // Form is valid, you can proceed with signup
            console.log("Form is valid");
            // Perform signup operation here
        }
    };

    return (
        <div className="login-popup">
            <form className="login-popup-container" onSubmit={handleSignUp}>
                <div className="login-popup-title">
                    <h2>{currState}</h2>
                    <img onClick={() => setShowLogin(false)} src={assets.cross_icon} alt="Close" />
                </div>
                <div className="login-popup-inputs">
                    {currState === "Login" ? <></> : <input type="text" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} required />}
                    <span className="error">{formErrors.name}</span>

                    <input type="email" placeholder="Your email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                    <span className="error">{formErrors.email}</span>

                    <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                    <span className="error">{formErrors.password}</span>
                </div>
                <button>{currState === "Sign Up" ? "Create account" : "Login"}</button>
                <div className="login-popup-condition">
                    <input type="checkbox" checked={agreeTerms} onChange={(e) => setAgreeTerms(e.target.checked)} required />
                    <p>By continuing, I agree to the terms of use & privacy policy</p>
                    <span className="error">{formErrors.agreeTerms}</span>
                </div>
                {currState === "Login" ?
                    <p>Create a new account? <span onClick={() => setCurrState("Sign Up")}>Click here</span></p>
                    :
                    <p>Already have an account? <span onClick={() => setCurrState("Login")}>Login here</span></p>
                }
            </form>
        </div>
    );
};

export default LoginPopup;
