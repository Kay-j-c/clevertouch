import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // Import Routes instead of Switch
import Navbar from './components/Navbar/Navbar';
import Footer from './components/Footer/Footer';
import LoginPopup from './components/LoginPopup/LoginPopup';
import Home from './Home';

const App = () => {
  const [showLogin, setShowLogin] = useState(false);

  return (
    <Router>
      <>
        {showLogin ? <LoginPopup /> : <></>}
        <div className='app'>
          <Navbar setShowLogin={setShowLogin}/>
          <Routes> {/* Use Routes instead of Switch */}
            <Route exact path="/" element={<Home />} /> {/* Use element prop */}
            {/* Define more routes for other pages here */}
          </Routes>
        </div>
        <Footer/>
      </>
    </Router>
  );
}

export default App;
