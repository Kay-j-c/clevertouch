import logo from './logo.png'
import cross_icon from './cross_icon.png'
import background from './background.jpg'
import education from './education.png'

export const assets = {
    logo,cross_icon, 
    background, education
}